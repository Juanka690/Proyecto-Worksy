package main;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conexion {
    
    public Connection conectar(){            
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            return DriverManager.getConnection(
            "jdbc:mysql://localhost:3306/iniciodesesion",
            "juankafut", "chelita97");          
        } 
        catch (ClassNotFoundException | SQLException ex) {
            System.out.println("Error: " + ex);
            return null; 
        }                       
    }               
}
    
    

